/*
 * computos.h
 *
 *  Created on: 20/09/2013
 *      Author: JoseLuis
 */

#ifndef COMPUTOS_H_
#define COMPUTOS_H_

void CS (int ms) ;

#endif /* COMPUTOS_H_ */
