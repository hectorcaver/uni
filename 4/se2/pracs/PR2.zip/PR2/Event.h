/*
 * Event.h
 *
 *  Created on: 9 oct. 2020
 *      Author: JoseLuis
  *
 *      Practica 2 de Sistemas Empotrados 2
 *      Planificacion DMS
 */

#ifndef EVENT_H_
#define EVENT_H_

void Init_Events (unsigned int T) ;
void Change_EventsPeriod (unsigned int T) ;

/*
 * It generates a square wave of period T. The rising edges are the events.
 */

#endif /* EVENT_H_ */
