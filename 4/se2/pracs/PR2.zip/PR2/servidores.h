/*
 * servidores.h
 *
 *  Created on: 30/09/2013
 *      Author: Jos� Luis Villarroel
 */

#ifndef SERVIDORES_H_
#define SERVIDORES_H_

void Crear_Servidores (void) ;

// Servidor S1
void S11 (void) ;
void S12 (void) ;

// Servidor S2
void S21 (void) ;
void S22 (void) ;


#endif /* SERVIDORES_H_ */
