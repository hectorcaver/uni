/*
 * computos.c
 *
 *  Created on: 20/09/2013
 *      Author: JoseLuis
 */
#include "computos.h"


void CS (int ms) {

	int i, j ;

    for (j = 0; j < ms; j++){
    	for (i = 0; i < 1410; i++) ;
    }

}
